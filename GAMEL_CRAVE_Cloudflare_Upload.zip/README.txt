GAMEL CRAVE installable web app package

Upload the contents of this folder to an HTTPS web host. Open the HTTPS address in a supported browser and choose Install app / Add to Home screen, or use the Install app button if the browser offers it.

This is a front-end prototype. Local browser storage is not a shared database. Camera and location need HTTPS and user permission. Selected files are not uploaded. Live video, real member accounts, worldwide posts, secure moderation and shared analytics need a secure backend and suitable services.
